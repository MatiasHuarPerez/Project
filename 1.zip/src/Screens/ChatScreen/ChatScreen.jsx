import React, { useState } from "react";
import MessagesList from "../../Components/MessagesList/MessageList";
import NewMessageForm from "../../Components/NewMessageForm/NewMessageForm";
import { useParams } from "react-router-dom";
import { getContactById } from "../../services/contactService";

const ChatScreen = () => {
  const { contact_id } = useParams();
  const contact_selected = getContactById(contact_id);

  if (!contact_selected) {
    return <div>Contacto no encontrado</div>;
  }

  const [messages, setMessages] = useState(contact_selected.messages || []);

  const deleteMessageById = (message_id) => {
    const new_message_list = messages.filter(
      (message) => message.id !== message_id
    );
    setMessages(new_message_list);
  };

  const addNewMessage = (text) => {
    const new_message = {
      emisor: "YO",
      hora: "11:10",
      texto: text,
      status: "no-visto",
      id: messages.length + 1,
    };
    setMessages([...messages, new_message]);
  };

  const deleteAllMessages = () => {
    setMessages([]);
  };

  return (
    <div>
      <h1>Mensajes con {contact_selected.nombre}:</h1>
      {messages.length > 0 && (
        <button onClick={deleteAllMessages}>Borrar todos los mensajes</button>
      )}
      <MessagesList
        messages={messages}
        deleteMessageById={deleteMessageById}
      />
      <NewMessageForm addNewMessage={addNewMessage} />
    </div>
  );
};

export default ChatScreen;

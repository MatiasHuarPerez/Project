
import React, { useState } from "react";
import ContactList from "../../Components/ContactList/ContactList";
import { getContactList } from "../../services/contactService";


const ContactScreen = ({ onSelectContact, selectedContact }) => {
  const contacts = getContactList();

  return (
    <div className="contact-screen">
      <div className="contact-list">
        {contacts.map(contact => (
          <div
            key={contact.id}
            className={`contact-item ${selectedContact?.id === contact.id ? 'active' : ''}`}
            onClick={() => onSelectContact(contact)}
          >
            <img src={contact.avatar} alt={contact.name} className="contact-avatar" />
            <div className="contact-info">
              <div className="contact-name">{contact.name}</div>
              <div className="contact-description">{contact.description}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ContactScreen;
import React, { useState, useEffect } from "react";
import { PiVideoCameraBold } from "react-icons/pi";
import { IoSearchOutline } from "react-icons/io5";
import { RxDotsVertical } from "react-icons/rx";
import NewMessageForm from "../NewMessageForm/NewMessageForm";

import contactService from "../../services/contactService";

function ChatPanel() {
  const [contacts, setContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);

  useEffect(() => {
    const fetchedContacts = contactService.getContacts();
    setContacts(fetchedContacts);
  }, []);

  const handleSelectContact = (contact) => {
    setSelectedContact(contact);
  };

  const handleSend = (messageText) => {
    const newMessage = {
      emisor: "YO",
      texto: messageText,
      hora: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      status: "enviado",
    };

    contactService.addMessageToContact(selectedContact.id, newMessage);
    const updated = contactService.getContactById(selectedContact.id);
    setSelectedContact({ ...updated });

    const updatedContacts = contactService.getContacts();
    setContacts(updatedContacts);
  };

  return (
    <>
      {/* Contact list */}
      <div className="contact-list">
        {contacts.map((contact) => (
          <div
            key={contact.id}
            className={`contact-item ${selectedContact?.id === contact.id ? "active" : ""}`}
            onClick={() => handleSelectContact(contact)}
          >
            <img src={contact.avatar} alt={contact.name} className="contact-avatar" />
            <div className="contact-info">
              <div className="contact-name">{contact.name}</div>
              <div className="contact-description">{contact.description}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Chat view */}
      <div className="chat-area">
        {selectedContact ? (
          <div className="chat-view">
            <div className="chat-header">
              <img src={selectedContact.avatar} alt="avatar" className="chat-header-avatar" />
              <span className="chat-header-name">{selectedContact.name}</span>
              <div className="chat-header-icons">
                <PiVideoCameraBold size={20} />
                <IoSearchOutline size={20} />
                <RxDotsVertical size={20} style={{ marginRight: 28 }} />
              </div>
            </div>

            <div className="chat-messages">
              {selectedContact.messages.map((msg, index) => (
                <div
                  key={index}
                  className={`chat-message ${msg.emisor === "YO" ? "yo" : "otro"}`}
                >
                  <div className="chat-message-text">{msg.texto}</div>
                  <div className="chat-message-time">{msg.hora}</div>
                </div>
              ))}
            </div>

            <NewMessageForm onSend={handleSend} />
          </div>
        ) : (
          <div className="chat-placeholder">Selecciona un contacto</div>
        )}
      </div>
    </>
  );
}

export default ChatPanel;

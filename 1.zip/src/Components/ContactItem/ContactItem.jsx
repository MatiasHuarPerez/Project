import React from "react";
import { Link } from "react-router-dom";

import ChatHeader from "../Header/Header";

const ContactItem = ({ contact }) => {
    return (
        <Link to={`/contact/${contact.id}/messages`} className="contact-item">
            <img src={contact.avatar} alt={contact.name} className="contact-avatar" />
            <div className="contact-info">
                <div className="contact-header">
                    <h2 className="contact-name">{contact.name}</h2>
                    <span className="contact-time">{contact.lastConnection}</span>
                </div>
                <span className={`contact-status ${contact.connectionStatus}`}>
                    {contact.connectionStatus}
                </span>
            </div>
        </Link>
    );
};

export default ContactItem;
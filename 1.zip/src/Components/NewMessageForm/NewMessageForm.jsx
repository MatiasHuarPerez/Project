import React, { useState } from 'react';
import { FaPlus } from 'react-icons/fa';
import { LuSticker } from 'react-icons/lu';
import { IoSend } from 'react-icons/io5';


function NewMessageForm({ onSend }) {
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim()) {
      onSend(message.trim());
      setMessage('');
    }
  };

  return (
    <form className="new-message-form" onSubmit={handleSubmit}>
      <FaPlus size={18} className="form-icon plus" />
      <LuSticker size={20} className="form-icon sticker" />
      <input
        type="text"
        placeholder="Escribe un mensaje..."
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        className="form-input"
      />
      <button type="submit" className="form-send-button">
        <IoSend size={20} color="white" />
      </button>
    </form>
  );
}

export default NewMessageForm;

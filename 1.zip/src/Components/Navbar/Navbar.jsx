import React from "react";
import { RxDotsVertical } from "react-icons/rx";
import { LuMessageSquarePlus } from "react-icons/lu";


const Navbar = () => {
  return (
    <div className="navbar">
      <div className="navbar-top">
        <h1 className="whatsapp-title">WhatsApp</h1>
        <div className="navbar-icons">
          <LuMessageSquarePlus className="navbar-icon" />
          <RxDotsVertical className="navbar-icon" />
        </div>
      </div>

      <input
        type="text"
        className="search-input"
        placeholder="Buscar o empezar un chat"
      />

      <div className="filter-buttons">
        <button>Todos</button>
        <button>No leídos</button>
        <button>Favoritos</button>
        <button>Grupos</button>
      </div>
    </div>
  );
};

export default Navbar;

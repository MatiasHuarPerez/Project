import React from "react";
import { Routes, Route } from "react-router-dom";
import Sidebar from "./Components/Sidebar/Sidebar";
import Navbar from "./Components/Navbar/Navbar";
import ChatPanel from "./Components/ChatPanel/ChatPanel"
import ChatScreen from "./Screens/ChatScreen/ChatScreen"
import "./App.css";

function App() {
  return (
    <div className="app">
      {/* Columna 1: Iconos laterales */}
      <div className="sidebar">
        <Sidebar />
      </div>

      {/* Columna 2: Navbar + Lista de contactos */}
      <div className="contacts-panel">
        <Navbar />

      </div>

      {/* Columna 3: Zona de chat dinámica */}
      <div className="chat-panel">
        <Routes>
          <Route path="/contact/:id" element={<ChatPanel />} />
          <Route path="/" element={<ChatScreen/>} />
        </Routes>
      </div>
    </div>
  );
}

export default App;

const contacts = [
  {
    id: 1,
    name: "Lionel Messi",
    avatar: "/images/messi.jpg",
    description: "En línea",
    messages: [
      { emisor: "otro", texto: "Hola, ¿cómo estás?", hora: "10:00", status: "recibido" },
      { emisor: "YO", texto: "Todo bien, ¿y vos?", hora: "10:01", status: "enviado" },
    ],
  },
  {
    id: 2,
    name: "Luis Suárez",
    avatar: "/images/suarez.jpg",
    description: "Últ. vez hoy a las 12:00",
    messages: [],
  },
  {
    id: 3,
    name: "Neymar Jr",
    avatar: "/images/neymar.jpg",
    description: "En línea",
    messages: [],
  },
];

export function getContacts() {
  return contacts;
}

export function getContactById(id) {
  return contacts.find((c) => c.id === id);
}

export function addMessageToContact(contactId, message) {
  const contact = contacts.find((c) => c.id === contactId);
  if (contact) {
    contact.messages.push(message);
  }
}

const contactService = {
  getContacts,
  getContactById,
  addMessageToContact,
};

export default contactService;
